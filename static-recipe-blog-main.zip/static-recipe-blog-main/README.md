# static-recipe-blog
 Static Next.JS 14 blog site using local markdown files
